gcc  -o hello_world hello_world.c -I ../include -L ../lib -lbdd -lmem -no-pie

