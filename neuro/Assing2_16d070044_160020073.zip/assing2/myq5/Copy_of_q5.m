close all;
clear;
t_max = 0.5;
dt = 0.1*10^-3;
lambda = 1;
io = 1*10^-12;
tou = 15*10^-3;
tou_s = tou/4;
m = t_max/dt;
wo = 200;
sig_w = 20;
w1(1:100,1)=(wo+sig_w*randn(100,1)); 
w2(1:100,1)=(wo+sig_w*randn(100,1)); 
w1 = w2;
stimulus1 = zeros(m,100);
stimulus2 = zeros(m,100);
 for k = 1:100
     threshold = lambda*dt;
     dum1 = rand(t_max/dt,1);
     dum2 = rand(t_max/dt,1);
     stimulus1(:,k) =logical(dum1<threshold);
     stimulus2(:,k) =logical(dum2<threshold);
     
 end

[pre_iapp1] = gen_iapp(stimulus1,t_max,dt,lambda,io,tou, tou_s,m,w1);
[V1,x1] = aef(pre_iapp1);
[pre_iapp2] = gen_iapp(stimulus2,t_max,dt,lambda,io,tou, tou_s,m,w2);
[V2,x2] = aef(pre_iapp2);
V1_d = V1;
V2_d = V2;
    figure(1)
    plot(x1,V1(:,1))
    title(["Part a S1"])
    xlabel('Time(in s)') 
    ylabel('Voltage (in V)')
        figure(2)
    plot(x2,V2(:,1))
    title(["Part a S2"])
    xlabel('Time(in s)') 
    ylabel('Voltage (in V)') 
%%%%%%%end part a(weights same)


%%%%%%start partb
itr = 1;
pre_V = V2;
pre_w = w2;

while(1)
    
    [post_w ,del_tk] = training(w2,dt,stimulus2,V2);
    [post_iapp] = gen_iapp(stimulus2,t_max,dt,lambda,io,tou, tou_s,m,post_w);
    [post_V,x] = aef(post_iapp);
    %del_w = post_w - pre_w;
    %del_w = nonzeros(del_w);
    %scattter(del_w,del_tk,'filled') 
    w2 = post_w;
    V2 = post_V;
    if max(post_V) ~= 0
        break
    end

    itr = itr +1;
end
w2_partb =  post_w;
V2_partb =  post_V;
figure(3)
plot(x1,V1(:,1))
title(["Part b S1"])
xlabel('Time(in s)') 
ylabel('Voltage (in V)')
figure(4)
plot(x2,post_V(:,1))
title(["Part b S2"])
xlabel('Time(in s)') 
ylabel('Voltage (in V)') 
    
  %%%%%part c
[pre_iapp_c] = gen_iapp(stimulus1,t_max,dt,lambda,io,tou, tou_s,m,w2_partb);
[V1_c,x1] = aef(pre_iapp_c);
figure(5)
plot(x1,V1_c(:,1))
title(["Part c S1"])
xlabel('Time(in s)') 
ylabel('Voltage (in V)')
    
    %%%%%partd
V1_d 
V2_d




